package com.rozdoum.socialcomponents.enums;

/**
 * Created by Alexey on 10.05.18.
 */
public enum FollowState {
    MY_PROFILE,
    USER_FOLLOW_ME,
    I_FOLLOW_USER,
    FOLLOW_EACH_OTHER,
    NO_ONE_FOLLOW
}
